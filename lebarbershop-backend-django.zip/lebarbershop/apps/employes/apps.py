from django.apps import AppConfig


class EmployesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.employes"
    label = "employes"
